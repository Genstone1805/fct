from django.contrib import admin
from .models import RouteFAQ, Route, Vehicle

admin.site.register(RouteFAQ)
admin.site.register(Route)
admin.site.register(Vehicle)
