from django.apps import AppConfig


class RoutesConfig(AppConfig):
    name = 'routes'
